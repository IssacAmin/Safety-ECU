#include "..\inc\can_tp.h"
/********************************************************************************************
*                                Global Variables                                          *
********************************************************************************************/
//variable to save the current state of the network layer
static NetworkLayerStatus_t networkLayerStatus= N_S_IDLE;

// Buffer to save the message received from the application (UDS)
static uint8_t dataBuffer[MAX_DATA_LENGTH];
// Variable to store the total message length
static uint8_t dataBufferLength= 0;

static uint8_t N_WFTcounter= 0;

/*********************************************************************************************
 *                                Functions Definition                                       *
 *********************************************************************************************/
 
/************************************************************************** 
 * Function Description:
 *      Consruct and directly transmit the message ob the CAN bus.
 *      The message is a single frame message.
 *    
 * Inputs:
 *      *data     : Pointer to the data buffer.
 *      dataLength: The length of the data bufferr.
 ***************************************************************************/
Std_ReturnType TransmitSingleFrame(uint8_t * data, uint8_t dataLength)
{
    SingleFrame_t sf;
    // Byte 0 LSB 
    sf.SF_PCI = SINGLE_FRAME_PCI_INDICATOR + dataLength;
    // Byte 0 MSB
    //sf.SF_PCI = (0x0 << 4) | (dataLength & 0x0F);


    // Start to fill the single frame data
    for(int i= 0 ; i < SINGLE_FRAME_DATA_SEND_SIZE ; ++i)
    {
        // If the current index is less than the max data length index (valid data) --> add it to the struct
        if(i < dataLength)
        {
            sf.Data[i]= data[i];
        }
        // If the current index is larger than the valid data length --> Pad the remaining enteries
        else
        {
            sf.Data[i]= 0x55;
        }
    }

    // Start transmitting the data to the Can If
    networkLayerStatus= N_S_TX_BUSY;

    // TODO: use the Can If API to send the constructed frame to it
    
}

/************************************************************************** 
 * Function Description:
 *      Consruct and directly transmit the First frame to the Can If.

 * Inputs:
 *      *data     : Pointer to the data buffer
 *      dataLength: The length of the data buffer
 ***************************************************************************/
Std_ReturnType TransmitFirstFrame(uint8_t * data, uint8_t dataLength)
{
    FirstFrame_t ff;
    
    // Byte 0 LSB 
    ff.FF_PCI= (uint16_t)(FIRST_FRAME_PCI_INDICATOR<<12) + dataLength;

    //Byte 0 is the MSB
    //ff.FF_PCI = (0x1 << 12) | (dataLength & 0x0FFF); 

    
    for(int i= 0 ; i < FIRST_FRAME_DATA_SEND_SIZE ; i++)
    {
        ff.Data[i]= data[i];
    }
    
    printf("First Frame: 0x%x ", ff.FF_PCI);
    for(int i= 0 ; i < FIRST_FRAME_DATA_SEND_SIZE ; i++)
    {
        printf("%x ", ff.Data[i]);
    }
    printf("\n");

    // TODO: Send FF, variable type FC by refrence to Can If
    
}


/*******************************************************************************************************
 * Function Description:
 *      Function that construct the consecutive frame (Add PCI and frame sequence number) and send it to
 *      the Can If based on the block size.
 *
 * Inputs:
 *      *data         : Pointer to the data buffer.
 *      sequenceNumber: The sequence number of the CF
 **********************************************************************************************************/
Std_ReturnType TransmitConsecutiveFrame(uint8_t * data, uint8_t sequnceNumber)
{
    uint8_t result= E_NOK;
    ConsecutiveFrame_t cf;
    static uint16_t bytesTransmitted= 6;

    static uint16_t remaingBytes= 0;

    remaingBytes= dataBufferLength - bytesTransmitted;
    printf("remaing bytes: %d\n\n", remaingBytes);

    if(NULL != data)
    {
        result= N_OK;

        cf.CF_PCI= (CONSECUTIVE_FRAME_PCI_INDICATOR<<4) | sequnceNumber;


        for(int i= 0 ; i < CONSECUTIVE_FRAME_DATA_SEND_SIZE ; ++i)
        {
            // If the current index is less than the max data length index (valid data) --> add it to the struct
            if(i < remaingBytes)
            {
                cf.Data[i]= data[i];
                bytesTransmitted++;
            }
            // End of the message to be sent
            else
            {
                cf.Data[i]= 0x55;
            }
        }
        
        if(remaingBytes <= 7)
        {
            networkLayerStatus= N_S_IDLE;
            bytesTransmitted= 6;
        }

        printf("Consecutive Frame: 0x%x ", cf.CF_PCI);
        for(int i= 0 ; i < CONSECUTIVE_FRAME_DATA_SEND_SIZE ; i++)
        {
            printf("%x ", cf.Data[i]);
        }
        printf("\n");
    }
    else
    {
        result= N_RESULT_ERROR;
    }
}

/*******************************************************************************************************
 * Function Description:
 *      API to requests transmission of message data with length bytes from the sender to the receiver
 *      peer entities over the network layer.
 *
 * Inputs:
 *      msg_type    : The type of the message (Diagnostic/Remote Diagnostic)
 *      address_info: The address information of the message
 *      *data       : Pointer to the data buffer
 *      data_length : The length of the data buffer
 **********************************************************************************************************/
ServiceResult_t N_USData_Request(MessageType_t msg_type, N_AI address_info, uint8_t * data, uint32_t data_length)
{
    /*
        1) Check the status of the service provider.
        2) Compare the data length with the maximum payload size for CAN frames to choose to send SF or FF+CF.
        3) If single frame --> transmit directly over the bus
           If Multi frames --> send FF
                                wait for FC frame --> time out if not received (return time out error)
                                                        if received --> send CF or wait for FC base on the BS value in the FC
    */
    // Variable to save the return value of the function
    ServiceResult_t result= N_RESULT_ERROR;

    // Parameters Checking (Make sure that the pointer is not pointing NULL) and the network layer
    // state is idle to handle the request
    if( (NULL != data) && (N_S_IDLE == networkLayerStatus) )
    {
        result= N_RESULT_OK;
    }
    else
    {
        result= N_RESULT_ERROR;
    }

    if(N_RESULT_OK == result)
    {
        // If the network layer is currently sending/recieving --> reject the current request
        // TODO: check the return value

        networkLayerStatus= N_S_TX_READY;
        
        // If the data length less than 8 bytes --> only single frame needed
        if(MAX_SINGLE_FRAME_DATA_LENGTH >= data_length) 
        {
            //Construct the Single Frame check on the 
            TransmitSingleFrame(data, data_length);

            // End of handling the request 
            networkLayerStatus= N_S_IDLE;
        }
        
        // If the data length greater than 8 bytes --> segment the data to Multi frame
        else 
        {
            dataBufferLength= data_length;
            for(int i=0 ; i < dataBufferLength ; i++)
            {
                dataBuffer[i]= data[i];
            }

            // call ff function and start timer 
            TransmitFirstFrame(dataBuffer, dataBufferLength);
            
            // Start Timer to detect the timeout
            WAIT_FLOW_CONTROL();

            networkLayerStatus= N_S_TX_WAIT_FC;
        }
            
    }
    else
    {
        // Do Nothing
        printf("\n\n\n\n Request Rejected: %x\n", networkLayerStatus);
    }


    return result;
}

void N_USData_Confirm(MessageType_t msg_type, N_AI address_info, ServiceResult_t result)
{

}

void N_USData_FFIndication(MessageType_t msg_type, N_AI address_info, uint32_t data_length)
{

}

/*******************************************************************************************************
 * Function Description:
 *      Call back function to handle the received data from the Can If and pass it to the application
 *
 * Inputs:
 *      msg_type    : The type of the message (Diagnostic/Remote Diagnostic).
 *      address_info: The address information of the message.
 *      *data       : Pointer to the data buffer.
 *      data_length : The length of the data buffer.
 *      *result     : the result of the service.
 **********************************************************************************************************/
 Std_ReturnType N_USData_Indication(MessageType_t msg_type, N_AI address_info, uint8_t * data, uint32_t data_length,  ServiceResult_t * result)
{
    uint8_t frameType= ((data[RECEIVED_FRAME_PCI_INDEX] & (uint8_t)FLOW_CONTROL_RECEIVED_FRAME_TYPE_MASK)>>4);
    uint8_t bs;   
    uint8_t STmin;
    uint8_t FC_Flag;

    printf("Data Indication: %x\n", data[RECEIVED_FRAME_PCI_INDEX]& (uint8_t)FLOW_CONTROL_RECEIVED_FRAME_TYPE_MASK);

    switch (frameType)
    {
        // Single Frame
        case SINGLE_FRAME_PCI_INDICATOR:
            for(int i = 0 ; i < data_length-1 ; ++i)
            {
                data[i]= data[i+1];
            }
            //TODO: send the singleFrameReceived to the application
            break;

        case FIRST_FRAME_PCI_INDICATOR:
            // N_USData_FFIndication();
            break;

        case CONSECUTIVE_FRAME_PCI:

            break;

        case FLOW_CONTROL_FRAME_PCI:
            if ( N_S_TX_WAIT_FC == networkLayerStatus)
            {
                bs     = data[FLOW_CONTROL_FRAME_BS_INDEX];
                STmin  = data[FLOW_CONTROL_FRAME_STMIN_INDEX];
                FC_Flag= data[FLOW_CONTROL_FRAME_FC_FLAG_INDEX] & FLOW_CONTROL_FC_FLAGS_MASK;

                networkLayerStatus= N_S_TX_BUSY;
                printf("fc: %x\n", FC_Flag);
                printf("Flow Control Frame: BS: %d, STmin: %d, FC_Flag: %d\n", bs, STmin, FC_Flag);
                ReceivedFlowControlFrameHandling(dataBuffer, bs, STmin, FC_Flag);
            }
            else
            {
                printf("Not waiting for FC frame right now\n");
                //TODO: send to the can If invalid FC frame received
            }
            break;
    }
}

Std_ReturnType ReceivedFlowControlFrameHandling(uint8_t *data, uint8_t blockSize, uint8_t St_min, uint8_t fc_flags)
{
    uint8_t result= E_NOK; 
    static uint8_t sequenceNumber= SEQUENCE_NUMBER_INIT_VALUE;
    static uint16_t byteNumber= BYTE_NUMBER_INIT_VALUE;

    // If the FS equals 0 --> continue sending CF
    if(fc_flags == FLOW_CONTROL_CONTINUE_TRANSMISSION)
    {
        /*
         * 1) Transmit CF based on the number of BS from the received FC frame
         * 2) If all consecutive frames are transmitted:
         *              --> 1) Change the network layer state to IDLE
         *                  2) reset the sequence number and byte number
         *    Else:
         *              --> 1) Change the network layer state to wait for the next FC frame
         *                  2) Start the timer to wait for the next FC frame
         */
        for(int i= 0 ; i < blockSize ; i++)
        {
            if( byteNumber < dataBufferLength )
            {
                TransmitConsecutiveFrame((dataBuffer + byteNumber), sequenceNumber);

                // After transmitting the consecutive frame successfully, point to the next seven byte
                // to send them in the next itteration
                byteNumber += 7;
                sequenceNumber= (sequenceNumber+1)%16;

                /*
                 * Check if this was the last CF in the message
                 */
                if(byteNumber > dataBufferLength)
                {
                    // send confirmation to the application
                    //TODO: Send the confirmation to the application
                    networkLayerStatus= N_S_IDLE;
                    sequenceNumber    = SEQUENCE_NUMBER_INIT_VALUE;
                    byteNumber        = BYTE_NUMBER_INIT_VALUE;
                    printf("Transmission Completed\n\n");
                    break;
                }
                else
                {
                    // TODO: Start the timer to wait for the next FC frame
                    WAIT_ST_MIN();
                }
            }
            else
            {
                // Do Nothing
            }
        }

        /*
         * If we transmitted n CF and waiting for the next FC to send new n CF:
         *              --> change the status of the Network layer to "WAITING FC frame"
         */
        if(byteNumber > dataBufferLength)
        {
            
        }
        else
        {
            // Do Nothing
            // Change the state of the network layer to wait for the next FC frame
            networkLayerStatus= N_S_TX_WAIT_FC;
        }

        result= N_RESULT_OK;
    }
    
    // If FC request to wait
    else if(fc_flags == FLOW_CONTROL_WAIT_FOR_TRANSMISSION)
    {
        // Increment the number of wait requestes requested by the receiver
        N_WFTcounter++;

        // Check if the wait requestes exceeds the maximum number
        if(MAX_WAIT_CONTROL_FRAMEs_COUNT > N_WFTcounter)
        {
            // TODO: start new timer waiting for the new FC to start transmission of the next CFs
            networkLayerStatus= N_S_TX_WAIT_FC;

            printf("Waiting for the next flow control frame...\n");
            result= E_OK;
        }
        else
        {
            /* 
             * If exceed the maximum number of wait requestes:
             *          --> 1) Change the stateof the network laye to IDLE
             *              2) Reset the variables value t obe ready for the next transmission
             *              3) Return "N_RESULT_WFT_OVRN"
             */
            networkLayerStatus= N_S_IDLE;
            sequenceNumber    = SEQUENCE_NUMBER_INIT_VALUE;
            byteNumber        = BYTE_NUMBER_INIT_VALUE;
            result            = N_RESULT_WFT_OVRN;
            printf("Transmission aborted \"Max count of wait request exceeded\"\n");
        }
    }
    // If the FS equals 2 --> abort transmission
    else if(fc_flags == FLOW_CONTROL_ABORT_TRANSMISSION)
    {
        /* 
         * If the FC wants to abort the transmission:
         *          --> 1) Change the state of the network laye to IDLE.
         *              2) Reset the variables value t obe ready for the next transmission.
         *              3) Return "N_RESULT_WFT_OVRN".
         */
        networkLayerStatus= N_S_IDLE;
        sequenceNumber    = SEQUENCE_NUMBER_INIT_VALUE;
        byteNumber        = BYTE_NUMBER_INIT_VALUE;
        result            = N_RESULT_BUFFER_OVFLW;
        printf("Transmission aborted \"FC Aborted\".\n");
    }
    // Invalid fc flag value
    else
    {
        result= N_RESULT_INVALID_FS;
    }

    return result;
}

int main()
{
    char data[] = {
        0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A,
        0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x14,
        0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E,
        0x1F, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28,
        0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F, 0x30, 0x31, 0x32,
        0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C,
        0x3D, 0x3E, 0x3F, 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46,
        0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F, 0x50,
        0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A,
        0x5B, 0x5C, 0x5D, 0x5E, 0x5F, 0x60, 0x61, 0x62, 0x63, 0x64,
        0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E,
        0x6F, 0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x78, 0x79,
        0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F, 0x80, 0x81, 0x82, 0x83
    };
    
    uint8_t data2[]= {0x11, 0x22, 0x33, 0x44, 0x75, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11};
    N_AI address_info;
    ServiceResult_t r;
    uint8_t fc[]= {0x30, 0x32, 0x01};
    
    
    N_USData_Request(0, address_info, data, 130);
    
    // Flow control frame
    N_USData_Indication(0, address_info, fc, 130, &r);

    N_USData_Request(0, address_info, data2, 17);
    fc[1]= 0x01;

    N_USData_Indication(0, address_info, fc, 16, &r);
    N_USData_Indication(0, address_info, fc, 16, &r);

    N_USData_Indication(0, address_info, fc, 16, &r);
    
    return 0;
}