#ifndef __CAN_TP_HEADER__
#define __CAN_TP_HEADER__


#include <stdint.h>
#include <stdio.h>
/********************************************************************************************
 *                                         MACROS                                           *
 ********************************************************************************************/
#define MAX_SINGLE_FRAME_DATA_LENGTH                 7
#define MAX_DATA_LENGTH                              4095
#define MAX_SEQUENCE_NUMBER                          15

#define SEQUENCE_NUMBER_INIT_VALUE                   1
#define BYTE_NUMBER_INIT_VALUE                       6

#define SINGLE_FRAME_DATA_SEND_SIZE                  7
#define FIRST_FRAME_DATA_SEND_SIZE                   6
#define CONSECUTIVE_FRAME_DATA_SEND_SIZE             7
        
#define SINGLE_FRAME_PCI_INDICATOR                   0x00
#define FIRST_FRAME_PCI_INDICATOR                    0x01
#define CONSECUTIVE_FRAME_PCI_INDICATOR              0x02
#define FLOW_CONTROL_FRAME_PCI_INDICATOR             0X03
        
#define FLOW_CONTROL_FC_FLAGS_MASK                   0x0F
#define FLOW_CONTROL_RECEIVED_FRAME_TYPE_MASK        0xF0
        
#define FLOW_CONTROL_FRAME_FC_FLAG_INDEX             0
#define FLOW_CONTROL_FRAME_BS_INDEX                  1
#define FLOW_CONTROL_FRAME_STMIN_INDEX               2
        
#define RECEIVED_FRAME_PCI_INDEX                     0
        
#define FLOW_CONTROL_CONTINUE_TRANSMISSION           0
#define FLOW_CONTROL_WAIT_FOR_TRANSMISSION           1
#define FLOW_CONTROL_ABORT_TRANSMISSION              2
        
#define MAX_WAIT_CONTROL_FRAMEs_COUNT                6


#define WAIT_FLOW_CONTROL()                  printf("Flow ctrl frame received\n")
#define WAIT_ST_MIN()                        printf("Waiting for ST min\n")
/********************************************************************************************
 *                                Type Definition                                           *
 ********************************************************************************************/
typedef enum{
    CAN_BASE_PHY,       //CAN 2.0 base 11 bit addressing - physical
    CAN_BASE_FUNC,      //CAN 2.0 base 11 bit addressing - functional
    CAN_EXT_PHY,        //CAN 2.0 EXTENDED 29 bit addressing - physical
    CAN_EXT_FUNC,       //CAN 2.0 EXTENDED 29 bit addressing - functional
    
}N_TAtype_t;

typedef enum{
    ST_MIN= 1,           // Min separation time between consecutive frames (MAX TIME 1 Sec)
    BS                   //BLOCK SIZE
}ParameterType_t;


typedef enum{
    DIAGNOSTIC,
    REMOTE_DIAGNOSTIC   //Remote adds to the N_AI the optional AE field
}MessageType_t;

typedef enum {
    N_RESULT_OK,           // Operation successful
    N_RESULT_TIMEOUT_A,    // Timeout occurred during transmission
    N_RESULT_TIMEOUT_Bs,   // Timeout waiting for Flow Control (FC) frame
    N_RESULT_TIMEOUT_Cr,   // Timeout waiting for Consecutive Frame (CF)
    N_RESULT_WRONG_SN,     // Sequence number mismatch in CF
    N_RESULT_INVALID_FS,   // Invalid Flow Status in FC frame
    N_RESULT_UNEXP_PDU,    // Unexpected Protocol Data Unit (PDU) received
    N_RESULT_WFT_OVRN,     // Wait Frame (WFT) overflow (too many WFTs)
    N_RESULT_BUFFER_OVFLW, // Buffer overflow (data exceeds available space)
    N_RESULT_ERROR         // General error
} ServiceResult_t;


typedef enum{
    N_OK,                   // Parameter change successful
    N_RX_ON,                //Reception process is ongoing (change not allowed)
    N_WRONG_PARAMETER,      // Invalid parameter ID requested
    N_WRONG_VALUE           // Invalid value assigned to the parameter
}ChangeParameterResult_t;


typedef enum{   
    CTS,                    //Continue to send
    WAIT,                   //wait
    OVFLW                   //Overflow
}FlowControlState_t;

typedef enum{   
    SINGLE_FRAME_PCI        = 0,       //Indicates type of frame (bit 7 - 4) in PCI               
    FIRST_FRAME_PCI         = 1,                  
    CONSECUTIVE_FRAME_PCI   = 2,
    FLOW_CONTROL_FRAME_PCI  = 3,                 
}FrameType_t;

typedef enum{
    SINGLE_FRAME,
    MULTI_FRAME
}TransmitFrame_t;

typedef enum {
    N_S_IDLE 	    = 0x00,     // Has to pending action 
	N_S_RX_BUSY 	= 0x02,     // Reception is in progress 
	N_S_TX_BUSY 	= 0x04,     // Transmission is in progress 
	N_S_TX_READY 	= 0x05,     // Transmission is ready to begin 
	N_S_TX_WAIT_FC 	= 0x10,     // Transmission is in progress and waits 

}NetworkLayerStatus_t;

typedef enum{
    E_OK,
    E_NOK
    
}Std_ReturnType;

//Defined Structs

typedef struct{
    uint8_t     N_SA;       //Source Address: encodes the sending network layer protocol entity 
    uint8_t     N_TA;       //Target Address: Encodes the recieving entity
    N_TAtype_t    N_TAtype;   //Target address type
    uint8_t     N_AE;       //optional address extenstion 
} N_AI;


typedef struct{
    uint8_t SF_PCI;         // 0x0000 + DATA LENGTH  [0 - 8]
    uint8_t Data[7];
}SingleFrame_t;

typedef struct{
    uint16_t FF_PCI;        // 0x0001 + DATA LENGTH [0 - 4095]
    uint8_t Data[6];
}FirstFrame_t;

typedef struct{
    uint8_t CF_PCI;         //0x0010 + Sequence Number
    uint8_t Data[7];
}ConsecutiveFrame_t;

typedef struct{
    uint8_t FC_PCI;                         // 0x0011 + FLOW STATE
    uint8_t FC_BS;                          // Block Size
    uint8_t FC_ST_MIN;                      // minimum separation time
    uint16_t Fill1;
    uint8_t Fill2;                          //NULL Data set as 0xAA 
}FlowControlFrame_t;

typedef struct{
    uint32_t N_As;                            //Timeout for N_PDU in sender side
    uint32_t N_Ar;                            //Timeout for N_PDU in receiver side
    uint32_t N_Bs;                            //
    uint32_t N_Cr;

}NetworkTimeouts;


typedef struct {
    /* sender paramters */
    uint32_t                    send_arbitration_id; /* used to reply consecutive frame */
    /* message buffer */
    uint8_t*                    send_buffer;
    uint16_t                    send_buf_size;
    uint16_t                    send_size;
    uint16_t                    send_offset;
    /* multi-frame flags */
    uint8_t                     send_sn;
    uint16_t                    send_bs_remain; /* Remaining block size */
    uint8_t                     send_st_min;    /* Separation Time between consecutive frames, unit millis */
    uint8_t                     send_wtf_count; /* Maximum number of FC.Wait frame transmissions  */
    uint32_t                    send_timer_st;  /* Last time send consecutive frame */    
    uint32_t                    send_timer_bs;  /* Time until reception of the next FlowControl N_PDU
                                                   start at sending FF, CF, receive FC
                                                   end at receive FC */
    int                         send_protocol_result;
    uint8_t                     send_status;                                                  
} IsoTpLinkTx_t;

typedef struct {
    /* receiver paramters */
    uint32_t                    receive_arbitration_id;
    /* message buffer */
    uint8_t*                    receive_buffer;
    uint16_t                    receive_buf_size;
    uint16_t                    receive_size;
    uint16_t                    receive_offset;
    /* multi-frame control */
    uint8_t                     receive_sn;
    uint8_t                     receive_bs_count; /* Maximum number of FC.Wait frame transmissions  */
    uint32_t                    receive_timer_cr; /* Time until transmission of the next ConsecutiveFrame N_PDU
                                                     start at sending FC, receive CF 
                                                     end at receive FC */
    int                         receive_protocol_result;
    uint8_t                     receive_status;                                                     
} IsoTpLinkRx_t;



/********************************************************************************************
 *                                Function Prototypes                                       *
 ********************************************************************************************/

/*******************************************************************************************************
 * Function Description:
 *      API to requests transmission of message data with length bytes from the sender to the receiver
 *      peer entities over the network layer.
 *
 * Inputs:
 *      msg_type    : The type of the message (Diagnostic/Remote Diagnostic)
 *      address_info: The address information of the message
 *      *data       : Pointer to the data buffer
 *      data_length : The length of the data buffer
 **********************************************************************************************************/
ServiceResult_t N_USData_Request(MessageType_t msg_type, N_AI address_info, uint8_t * data, uint32_t data_length);

/*******************************************************************************************************
 * Function Description:
 *      Call back function to handle the received data from the Can If and pass it to the application
 *
 * Inputs:
 *      msg_type    : The type of the message (Diagnostic/Remote Diagnostic).
 *      address_info: The address information of the message.
 *      *data       : Pointer to the data buffer.
 *      data_length : The length of the data buffer.
 *      *result     : the result of the service.
 **********************************************************************************************************/
Std_ReturnType N_USData_Indication(MessageType_t msg_type, N_AI address_info, uint8_t * data, uint32_t data_length,  ServiceResult_t * result);

void N_USData_Confirm(MessageType_t msg_type, N_AI address_info, ServiceResult_t result);

void N_USData_FFIndication(MessageType_t msg_type, N_AI address_info, uint32_t data_length);

//ServiceResult_t N_CanTp_Transmit(MessageType_t transmit_type, IsoTpLink_Tx tx_flags);

/************************************************************************** 
 * Function Description:
 *      Consruct and directly transmit the message ob the CAN bus.
 *      The message is a single frame message.
 *    
 * Inputs:
 *      *data     : Pointer to the data buffer.
 *      dataLength: The length of the data bufferr.
 ***************************************************************************/
Std_ReturnType TransmitSingleFrame(uint8_t * data, uint8_t dataLength);

/************************************************************************** 
 * Function Description:
 *      Consruct and directly transmit the First frame to the Can If.
 *
 * Inputs:
 *      *data     : Pointer to the data buffer
 *      dataLength: The length of the data buffer
 ***************************************************************************/
Std_ReturnType TransmitFirstFrame(uint8_t * data, uint8_t dataLength);

Std_ReturnType TransmitConsecutiveFrame(uint8_t * data, uint8_t sequnceNumber);

Std_ReturnType ReceivedFlowControlFrameHandling(uint8_t *data, uint8_t blockSize, uint8_t St_min, uint8_t fc_flags);

#endif
